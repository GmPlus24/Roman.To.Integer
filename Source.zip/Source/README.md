This program is created with Python and PyQt and also using Qt Designer. For converting Roman number to Integer

Python Website: https://www.python.org/ Qt Website: https://www.qt.io/

CC License: RomanToInteger © 2024 by Gm is licensed under CC BY-SA 4.0